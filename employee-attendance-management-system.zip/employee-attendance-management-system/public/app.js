const $ = (id) => document.getElementById(id);

function showToast(message, error = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.style.background = error ? "#a33a3a" : "#172033";
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2800);
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

function formatTime(value) {
  return value ? new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—";
}
function formatHours(minutes = 0) {
  return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
}
function badge(status) {
  const cls = status === "Present" ? "green" :
              status === "Half Day" ? "orange" :
              status === "On Leave" ? "orange" :
              status === "Rejected" ? "red" : "gray";
  return `<span class="badge ${cls}">${status}</span>`;
}

document.querySelectorAll(".tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const login = btn.dataset.auth === "login";
    $("loginForm").classList.toggle("hidden", !login);
    $("registerForm").classList.toggle("hidden", login);
  });
});

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({
        email: $("loginEmail").value,
        password: $("loginPassword").value
      })
    });
    showToast(data.message);
    await loadApp();
  } catch (err) { showToast(err.message, true); }
});

$("registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/register", {
      method: "POST",
      body: JSON.stringify({
        name: $("regName").value,
        email: $("regEmail").value,
        password: $("regPassword").value
      })
    });
    showToast(data.message);
    $("registerForm").reset();
    document.querySelector('[data-auth="login"]').click();
  } catch (err) { showToast(err.message, true); }
});

$("logoutBtn").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" }).catch(() => {});
  $("appPage").classList.add("hidden");
  $("authPage").classList.remove("hidden");
});

$("checkInBtn").addEventListener("click", async () => {
  try {
    const data = await api("/api/attendance/check-in", { method: "POST" });
    showToast(data.message);
    loadEmployee();
  } catch (err) { showToast(err.message, true); }
});

$("checkOutBtn").addEventListener("click", async () => {
  try {
    const data = await api("/api/attendance/check-out", { method: "POST" });
    showToast(data.message);
    loadEmployee();
  } catch (err) { showToast(err.message, true); }
});

$("leaveForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/leaves", {
      method: "POST",
      body: JSON.stringify({
        startDate: $("leaveStart").value,
        endDate: $("leaveEnd").value,
        reason: $("leaveReason").value
      })
    });
    showToast(data.message);
    $("leaveForm").reset();
    loadEmployee();
  } catch (err) { showToast(err.message, true); }
});

$("hrDate").addEventListener("change", () => loadHR());

async function loadEmployee() {
  const data = await api("/api/employee/dashboard");
  const a = data.today;

  $("todayStatus").textContent = a.status;
  $("todayHours").textContent = formatHours(a.working_minutes);
  $("leaveBalance").textContent = `${data.leave.remaining} days`;
  $("checkIn").textContent = formatTime(a.check_in);
  $("checkOut").textContent = formatTime(a.check_out);

  const badgeEl = $("attendanceBadge");
  badgeEl.outerHTML = `<span id="attendanceBadge" class="badge ${a.check_in ? (a.check_out ? "green" : "orange") : "gray"}">${a.check_in ? (a.check_out ? "Completed" : "Checked in") : "Not checked in"}</span>`;

  $("checkInBtn").disabled = Boolean(a.check_in);
  $("checkOutBtn").disabled = !a.check_in || Boolean(a.check_out);
  $("checkInBtn").style.opacity = $("checkInBtn").disabled ? ".5" : "1";
  $("checkOutBtn").style.opacity = $("checkOutBtn").disabled ? ".5" : "1";

  $("employeeHistory").innerHTML = data.history.length ? data.history.map(r => `
    <tr>
      <td>${r.work_date}</td>
      <td>${formatTime(r.check_in)}</td>
      <td>${formatTime(r.check_out)}</td>
      <td>${formatHours(r.working_minutes)}</td>
      <td>${badge(r.status)}</td>
    </tr>
  `).join("") : `<tr><td colspan="5">No attendance records yet.</td></tr>`;
}

async function loadHR() {
  const selected = $("hrDate").value || new Date().toISOString().slice(0, 10);
  $("hrDate").value = selected;
  const data = await api(`/api/hr/dashboard`);
  const attendance = await api(`/api/hr/attendance?date=${encodeURIComponent(selected)}`);

  $("employeeCount").textContent = data.stats.employeeCount;
  $("presentCount").textContent = attendance.rows.filter(x => x.status === "Present" || x.status === "Half Day").length;
  $("onLeaveCount").textContent = attendance.rows.filter(x => x.status === "On Leave").length;
  $("pendingCount").textContent = data.stats.pendingLeaves;

  $("hrEmployees").innerHTML = attendance.rows.length ? attendance.rows.map(r => `
    <tr>
      <td>${escapeHtml(r.name)}</td>
      <td>${escapeHtml(r.email)}</td>
      <td>${formatTime(r.check_in)}</td>
      <td>${formatTime(r.check_out)}</td>
      <td>${formatHours(r.working_minutes)}</td>
      <td>${badge(r.status)}</td>
    </tr>
  `).join("") : `<tr><td colspan="6">No employees found.</td></tr>`;

  $("hrLeaves").innerHTML = data.leaves.length ? data.leaves.map(l => `
    <tr>
      <td><strong>${escapeHtml(l.name)}</strong><br><small>${escapeHtml(l.email)}</small></td>
      <td>${l.start_date} → ${l.end_date}</td>
      <td>${l.days} day(s)</td>
      <td>${escapeHtml(l.reason || "—")}</td>
      <td>
        ${l.status === "Pending" ? `
          <div class="action-buttons">
            <button class="approve" onclick="updateLeave(${l.id}, 'Approved')">Approve</button>
            <button class="reject" onclick="updateLeave(${l.id}, 'Rejected')">Reject</button>
          </div>
        ` : badge(l.status)}
      </td>
    </tr>
  `).join("") : `<tr><td colspan="5">No leave requests yet.</td></tr>`;
}

window.updateLeave = async (id, status) => {
  try {
    const data = await api(`/api/hr/leaves/${id}/status`, {
      method: "POST",
      body: JSON.stringify({ status })
    });
    showToast(data.message);
    loadHR();
  } catch (err) { showToast(err.message, true); }
};

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[c]));
}

async function loadApp() {
  try {
    const data = await api("/api/me");
    $("authPage").classList.add("hidden");
    $("appPage").classList.remove("hidden");
    $("welcome").textContent = `${data.user.name} • ${data.user.role.toUpperCase()}`;
    $("currentDate").textContent = new Date().toLocaleDateString(undefined, {
      weekday: "long", year: "numeric", month: "long", day: "numeric"
    });

    const employee = data.user.role === "employee";
    $("employeeView").classList.toggle("hidden", !employee);
    $("hrView").classList.toggle("hidden", employee);

    if (employee) await loadEmployee();
    else await loadHR();
  } catch {
    $("appPage").classList.add("hidden");
    $("authPage").classList.remove("hidden");
  }
}

loadApp();
